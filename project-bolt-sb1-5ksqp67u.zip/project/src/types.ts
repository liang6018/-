export interface PatientData {
  patientId: string;
  gender: string;
  year: number;
  height: number;
  weight: number;
  bmi: number;
  systolicBP: number;
  diastolicBP: number;
  wbc: number;
  rbc: number;
  hb: number;
  plt: number;
  urineProtein: string;
  urineBlood: string;
  urineSugar: string;
  gpt: number;
  got: number;
  fbs: number;
  totalCholesterol: number;
  triglyceride: number;
}

export interface AbnormalSuggestion {
  possibleDiseases: string[];
  solutions: string[];
}

export interface GenderSpecificRange {
  min: number;
  max: number;
}

export interface GenderSpecificWarningThreshold {
  highMin: number;
  lowMax: number;
}

export interface ReferenceData {
  [key: string]: {
    normalRange: {
      unit: string;
      min?: number | null;
      max?: number | null;
      male?: GenderSpecificRange;
      female?: GenderSpecificRange;
    };
    abnormal: {
      high?: AbnormalSuggestion;
      low?: AbnormalSuggestion;
    };
    warningThreshold: {
      highMin?: number;
      lowMax?: number;
      male?: GenderSpecificWarningThreshold;
      female?: GenderSpecificWarningThreshold;
    };
  };
}

export interface UserCredentials {
  patientId: string;
  idNumber: string;
}

export interface WarningData {
  name: string;
  value: number;
  normalRange: string;
  status: 'approaching-high' | 'approaching-low';
  description: string;
}

export interface TrendData {
  name: string;
  isBad: boolean;
  message: string;
}

export interface NormalRange {
  unit: string;
  male?: {
    min: number;
    max: number;
  };
  female?: {
    min: number;
    max: number;
  };
  min?: number | null;
  max?: number | null;
}