import { ReferenceData } from '../types';

export const referenceData: ReferenceData = {
  height: {
    normalRange: {
      min: null,
      max: null,
      unit: 'cm'
    },
    abnormal: {},
    warningThreshold: {}
  },
  weight: {
    normalRange: {
      min: null,
      max: null,
      unit: 'kg'
    },
    abnormal: {},
    warningThreshold: {}
  },
  bmi: {
    normalRange: {
      min: 18.5,
      max: 24,
      unit: 'kg/m²'
    },
    abnormal: {
      high: {
        possibleDiseases: ['肥胖', '代謝症候群', '脂肪肝'],
        solutions: ['均衡飲食', '規律運動', '控制熱量攝取']
      },
      low: {
        possibleDiseases: ['營養不良', '消化系統疾病'],
        solutions: ['增加熱量攝取', '均衡飲食', '定期追蹤體重']
      }
    },
    warningThreshold: {
      highMin: 23.45,
      lowMax: 19.05
    }
  },
  systolicBP: {
    normalRange: {
      min: 90,
      max: 120,
      unit: 'mmHg'
    },
    abnormal: {
      high: {
        possibleDiseases: ['高血壓', '心血管疾病'],
        solutions: ['低鹽飲食', '規律運動', '戒菸限酒', '控制壓力']
      },
      low: {
        possibleDiseases: ['低血壓', '貧血'],
        solutions: ['適量補充水分', '增加鹽分攝取', '避免長時間站立']
      }
    },
    warningThreshold: {
      highMin: 117,
      lowMax: 93
    }
  },
  diastolicBP: {
    normalRange: {
      min: 60,
      max: 80,
      unit: 'mmHg'
    },
    abnormal: {
      high: {
        possibleDiseases: ['高血壓', '腎臟疾病'],
        solutions: ['低鹽飲食', '規律運動', '戒菸限酒', '控制壓力']
      },
      low: {
        possibleDiseases: ['低血壓'],
        solutions: ['適量補充水分', '增加鹽分攝取']
      }
    },
    warningThreshold: {
      highMin: 78,
      lowMax: 62
    }
  },
  wbc: {
    normalRange: {
      min: 3.25,
      max: 9.16,
      unit: 'x10³/μL'
    },
    abnormal: {
      high: {
        possibleDiseases: ['感染', '發炎', '白血病'],
        solutions: ['就醫診治', '抗生素治療（需醫師處方）']
      },
      low: {
        possibleDiseases: ['病毒感染', '骨髓功能異常', '自體免疫疾病'],
        solutions: ['就醫診治', '增強免疫力', '均衡飲食']
      }
    },
    warningThreshold: {
      highMin: 8.569,
      lowMax: 3.841
    }
  },
  rbc: {
    normalRange: {
      unit: 'x10⁶/μL',
      male: {
        min: 4.21,
        max: 5.9
      },
      female: {
        min: 3.78,
        max: 5.25
      }
    },
    abnormal: {
      high: {
        possibleDiseases: ['真性紅血球增多症', '脫水'],
        solutions: ['就醫診治', '充分補充水分']
      },
      low: {
        possibleDiseases: ['貧血', '營養不良', '慢性疾病'],
        solutions: ['補充鐵質', '均衡飲食', '就醫診治']
      }
    },
    warningThreshold: {
      male: {
        highMin: 5.731,
        lowMax: 4.379
      },
      female: {
        highMin: 5.103,
        lowMax: 3.927
      }
    }
  },
  hb: {
    normalRange: {
      unit: 'g/dL',
      male: {
        min: 13.1,
        max: 17.2
      },
      female: {
        min: 11.0,
        max: 15.2
      }
    },
    abnormal: {
      high: {
        possibleDiseases: ['真性紅血球增多症', '肺部疾病', '脫水'],
        solutions: ['就醫診治', '充分補充水分']
      },
      low: {
        possibleDiseases: ['貧血', '失血', '慢性疾病'],
        solutions: ['補充鐵質', '均衡飲食', '就醫診治']
      }
    },
    warningThreshold: {
      male: {
        highMin: 16.79,
        lowMax: 13.51
      },
      female: {
        highMin: 14.78,
        lowMax: 11.42
      }
    }
  },
  plt: {
    normalRange: {
      min: 150,
      max: 378,
      unit: 'x10³/μL'
    },
    abnormal: {
      high: {
        possibleDiseases: ['感染', '發炎', '血小板增多症'],
        solutions: ['就醫診治', '定期追蹤']
      },
      low: {
        possibleDiseases: ['血小板減少症', '骨髓疾病', '自體免疫疾病'],
        solutions: ['就醫診治', '避免外傷', '定期追蹤']
      }
    },
    warningThreshold: {
      highMin: 355.2,
      lowMax: 172.8
    }
  },
  gpt: {
    normalRange: {
      min: 0,
      max: 41,
      unit: 'U/L'
    },
    abnormal: {
      high: {
        possibleDiseases: ['肝功能異常', '藥物性肝損傷', '脂肪肝'],
        solutions: ['避免飲酒', '均衡飲食', '就醫診治']
      }
    },
    warningThreshold: {
      highMin: 36.9
    }
  },
  got: {
    normalRange: {
      min: 8,
      max: 31,
      unit: 'U/L'
    },
    abnormal: {
      high: {
        possibleDiseases: ['肝功能異常', '藥物性肝損傷', '心肌損傷'],
        solutions: ['避免飲酒', '均衡飲食', '就醫診治']
      },
      low: {
        possibleDiseases: ['肝功能衰退', '營養不良', '慢性肝病'],
        solutions: ['均衡營養', '規律作息', '就醫追蹤']
      }
    },
    warningThreshold: {
      highMin: 28.7,
      lowMax: 10.3
    }
  },
  fbs: {
    normalRange: {
      min: 70,
      max: 100,
      unit: 'mg/dL'
    },
    abnormal: {
      high: {
        possibleDiseases: ['糖尿病', '代謝症候群'],
        solutions: ['控制碳水化合物攝取', '規律運動', '控制體重', '就醫診治']
      },
      low: {
        possibleDiseases: ['低血糖', '肝功能異常', '內分泌疾病'],
        solutions: ['定時進食', '適量攝取碳水化合物', '就醫診治']
      }
    },
    warningThreshold: {
      highMin: 97,
      lowMax: 77
    }
  },
  totalCholesterol: {
    normalRange: {
      min: 0,
      max: 200,
      unit: 'mg/dL'
    },
    abnormal: {
      high: {
        possibleDiseases: ['高血脂症', '動脈粥狀硬化', '心血管疾病風險增加'],
        solutions: ['低脂飲食', '規律運動', '控制體重', '就醫診治']
      }
    },
    warningThreshold: {
      highMin: 180
    }
  },
  triglyceride: {
    normalRange: {
      min: 0,
      max: 150,
      unit: 'mg/dL'
    },
    abnormal: {
      high: {
        possibleDiseases: ['高三酸甘油脂血症', '脂肪肝', '胰臟炎', '代謝症候群'],
        solutions: ['減少精緻糖和碳水化合物攝取', '規律運動', '控制體重', '就醫診治']
      }
    },
    warningThreshold: {
      highMin: 135
    }
  },
  urineProtein: {
    normalRange: {
      min: null,
      max: null,
      unit: ''
    },
    abnormal: {
      high: {
        possibleDiseases: ['腎臟疾病', '尿路感染', '高血壓腎損傷'],
        solutions: ['增加水分攝取', '就醫診治', '低鹽飲食']
      }
    },
    warningThreshold: {}
  },
  urineBlood: {
    normalRange: {
      min: null,
      max: null,
      unit: ''
    },
    abnormal: {
      high: {
        possibleDiseases: ['尿路感染', '腎臟疾病', '泌尿系統結石'],
        solutions: ['增加水分攝取', '就醫診治']
      }
    },
    warningThreshold: {}
  },
  urineSugar: {
    normalRange: {
      min: null,
      max: null,
      unit: ''
    },
    abnormal: {
      high: {
        possibleDiseases: ['糖尿病', '腎臟疾病', '妊娠糖尿病'],
        solutions: ['控制碳水化合物攝取', '規律運動', '就醫診治']
      }
    },
    warningThreshold: {}
  }
};