import { PatientData } from '../types';
import Papa from 'papaparse';

// 將CSV數據轉換為PatientData陣列
const parseCSVData = (csvString: string): PatientData[] => {
  const results = Papa.parse(csvString, {
    header: true,
    skipEmptyLines: true
  });

  if (results.errors.length > 0) {
    console.error('CSV parsing errors:', results.errors);
    return [];
  }

  return results.data.map((row: any) => ({
    patientId: row['病歷號'],
    gender: row['性別'],
    year: parseInt(row['年份']),
    height: parseFloat(row['身高(cm)']),
    weight: parseFloat(row['體重(kg)']),
    bmi: parseFloat(row['BMI']),
    systolicBP: parseFloat(row['收縮壓(mmHg)']),
    diastolicBP: parseFloat(row['舒張壓(mmHg)']),
    wbc: parseFloat(row['白血球(WBC,x10³/μL)']),
    rbc: parseFloat(row['紅血球(RBC,x10⁶/μL)']),
    hb: parseFloat(row['血紅素(Hb, g/dL)']),
    plt: parseFloat(row['血小板(PLT,x10³/μL)']),
    urineProtein: row['尿蛋白'],
    urineBlood: row['尿潛血'],
    urineSugar: row['尿糖'],
    gpt: parseFloat(row['GPT(U/L)']),
    got: parseFloat(row['GOT(U/L)']),
    fbs: parseFloat(row['空腹血糖(FBS, mg/dL)']),
    totalCholesterol: parseFloat(row['總膽固醇(mg/dL)']),
    triglyceride: parseFloat(row['三酸甘油脂(TG, mg/dL)'])
  }));
};

// 驗證使用者資料的函數
export const validateUser = (patientId: string, idNumber: string): boolean => {
  const expectedIdNumber = `D${patientId.repeat(9)}`;
  return idNumber === expectedIdNumber;
};

// 根據病歷號獲取該病人所有年份的資料
export const getPatientDataById = (patientId: string): PatientData[] => {
  const csvData = `病歷號,性別,年份,身高(cm),體重(kg),BMI,收縮壓(mmHg),舒張壓(mmHg),"白血球(WBC,x10³/μL)","紅血球(RBC,x10⁶/μL)","血紅素(Hb, g/dL)","血小板(PLT,x10³/μL)",尿蛋白,尿潛血,尿糖,GPT(U/L),GOT(U/L),"空腹血糖(FBS, mg/dL)",總膽固醇(mg/dL),"三酸甘油脂(TG, mg/dL)"
1,female,2020,163,55,20.7,108,63.1,5.1,4.3,14.2,333,陰性,陰性,陰性,28.3,7.6,76.2,138.6,56.1
1,female,2021,163,56.3,21.2,108,64.4,5.2,4.3,14.1,295.7,陰性,陰性,陰性,30,8.3,78.1,142,57
1,female,2022,163,59,22.2,112,65,5.2,4.2,14.1,291.3,陰性,陰性,陰性,31.2,12,79.2,146,60
1,female,2023,163,63.4,23.9,114,66,5.2,4.2,13.4,288.3,陰性,陰性,陰性,33,18,81,152.3,62.3
1,female,2024,163,65.8,24.8,117,67,5.3,4.1,13.1,280,陰性,陰性,陰性,34.1,18.3,84,154,64
2,female,2020,160,66,25.8,61.1,56,5,4.7,14.5,264,陰性,陰性,陰性,31.4,8,71.3,170.6,54.6
2,female,2021,160,66.5,26,61.2,59,5.1,4.7,14.3,260.8,陰性,陰性,陰性,33.8,9,72.4,171.2,56
2,female,2022,160,67,26.2,64.3,62,5.1,4.6,14.1,257.5,陰性,陰性,陰性,33.9,10,74,173,57.5
2,female,2023,160,67.5,26.4,66,71.2,5.1,4.6,13.9,205,陰性,陰性,陰性,34.5,11,75.3,175.3,59
2,female,2024,160,80,29.3,66.1,72.3,5.2,4.5,13.7,248.3,陰性,陰性,陰性,34.9,12,75.9,178,60.5
3,male,2020,182,77,23.2,116.1,76.1,15.2,5.6,15.2,351.9,陰性,陰性,陰性,35.8,12.7,82.4,186.4,134
3,male,2021,182,77.5,23.4,117,77.2,15.3,5.5,15.1,342.9,陰性,陰性,陰性,37.4,13,84,190.2,136
3,male,2022,182,78,23.5,118,78.1,15.3,5.5,15,341.5,陰性,陰性,陰性,38.2,13.2,88,191.4,137.5
3,male,2023,182,78.5,23.7,118.3,78.4,15.5,5.5,14.8,338.8,陰性,陰性,陰性,39.9,14,89,191.5,138.2
3,male,2024,182,79,23.8,120,79,15.5,5.4,14.7,335,陰性,陰性,陰性,41,14.9,91,197,140
4,male,2020,150,65,28.9,96.7,62.4,6.4,5.7,14.3,279.7,陰性,陰性,陰性,28.1,14.5,112,162.3,69.6
4,male,2021,150,68,30.2,98.3,63,6.5,5.6,14.2,277.4,陰性,陰性,陰性,29,15,114,164.4,71.2
4,male,2022,150,69.2,30.8,99.1,63.8,6.5,5.5,14.1,273.5,陰性,陰性,陰性,31.4,15.5,116,168.9,71.3
4,male,2023,150,70.5,31.3,99.6,64,6.5,5.3,14,271,陰性,陰性,陰性,31.9,16,118.4,170,73
4,male,2024,150,71.1,31.6,99.9,64.5,6.6,5.3,13.9,268.9,陰性,陰性,陰性,32.1,16.5,119.2,171.2,75`;

  const allData = parseCSVData(csvData);
  return allData.filter(data => data.patientId === patientId);
};

// 根據病歷號和年份獲取數據
export const getPatientDataByIdAndYear = (patientId: string, year: number): PatientData | undefined => {
  const patientData = getPatientDataById(patientId);
  return patientData.find(data => data.year === year);
};