import React, { createContext, useState, useContext, ReactNode } from 'react';
import { validateUser } from '../data/mockData';
import { UserCredentials } from '../types';

interface AuthContextType {
  isAuthenticated: boolean;
  patientId: string | null;
  error: string | null;
  login: (credentials: UserCredentials) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [patientId, setPatientId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const login = (credentials: UserCredentials): boolean => {
    const { patientId, idNumber } = credentials;
    
    // 驗證登入
    const isValid = validateUser(patientId, idNumber);
    
    if (isValid) {
      setIsAuthenticated(true);
      setPatientId(patientId);
      setError(null);
      return true;
    } else {
      setError('病歷號或身份證字號有誤，請重新輸入');
      return false;
    }
  };

  const logout = () => {
    setIsAuthenticated(false);
    setPatientId(null);
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, patientId, error, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};