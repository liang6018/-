import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import { PatientData, TrendData, WarningData } from '../types';
import { getPatientDataById, getPatientDataByIdAndYear } from '../data/mockData';
import { analyzeTrend, getWarningData } from '../utils/dataUtils';
import { useAuth } from './AuthContext';

interface DataContextType {
  patientData: PatientData[];
  currentYearData: PatientData | undefined;
  warningData: WarningData[];
  trendData: TrendData[];
  selectedYear: number;
  setSelectedYear: (year: number) => void;
  loading: boolean;
  error: string | null;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { patientId } = useAuth();
  const [patientData, setPatientData] = useState<PatientData[]>([]);
  const [currentYearData, setCurrentYearData] = useState<PatientData | undefined>(undefined);
  const [warningData, setWarningData] = useState<WarningData[]>([]);
  const [trendData, setTrendData] = useState<TrendData[]>([]);
  const [selectedYear, setSelectedYear] = useState<number>(2024);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // 載入病人資料
  useEffect(() => {
    if (!patientId) return;
    
    try {
      setLoading(true);
      const data = getPatientDataById(patientId);
      setPatientData(data);
      setLoading(false);
    } catch (err) {
      setError('無法載入病人資料');
      setLoading(false);
    }
  }, [patientId]);

  // 當年份或資料變更時，更新目前年份資料
  useEffect(() => {
    if (!patientId || patientData.length === 0) return;
    
    const yearData = getPatientDataByIdAndYear(patientId, selectedYear);
    setCurrentYearData(yearData);
    
    if (yearData) {
      setWarningData(getWarningData(yearData));
    } else {
      setWarningData([]);
    }
  }, [patientId, patientData, selectedYear]);

  // 分析趨勢
  useEffect(() => {
    if (patientData.length === 0) return;

    const trendsToAnalyze = [
      'bmi', 'systolicBP', 'diastolicBP', 'wbc', 'rbc', 
      'hb', 'plt', 'gpt', 'got', 'fbs', 'totalCholesterol', 'triglyceride'
    ] as const;
    
    const trends: TrendData[] = [];
    
    for (const key of trendsToAnalyze) {
      const trend = analyzeTrend(patientData, key);
      if (trend && trend.isBad) {
        trends.push(trend);
      }
    }
    
    setTrendData(trends);
  }, [patientData]);

  return (
    <DataContext.Provider value={{
      patientData,
      currentYearData,
      warningData,
      trendData,
      selectedYear,
      setSelectedYear,
      loading,
      error
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = (): DataContextType => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};