import { PatientData, ReferenceData, WarningData, TrendData } from '../types';
import { referenceData } from '../data/referenceData';
import Papa from 'papaparse';

// 檢查數值是否異常
export const isAbnormal = (key: string, value: number, gender?: string): boolean => {
  const reference = referenceData[key];
  if (!reference) return false;
  
  let min: number | null = null;
  let max: number | null = null;
  
  if (reference.normalRange.male && reference.normalRange.female && gender) {
    const genderRange = gender === 'male' ? reference.normalRange.male : reference.normalRange.female;
    min = genderRange.min;
    max = genderRange.max;
  } else {
    min = reference.normalRange.min || null;
    max = reference.normalRange.max || null;
  }
  
  if (min !== null && value < min) return true;
  if (max !== null && value > max) return true;
  
  return false;
};

// 檢查數值是否接近超標
export const isApproachingAbnormal = (key: string, value: number, gender?: string): 'approaching-high' | 'approaching-low' | null => {
  const reference = referenceData[key];
  if (!reference) return null;
  
  let min: number | null = null;
  let max: number | null = null;
  let highMin: number | undefined;
  let lowMax: number | undefined;
  
  if (reference.normalRange.male && reference.normalRange.female && gender) {
    const genderRange = gender === 'male' ? reference.normalRange.male : reference.normalRange.female;
    min = genderRange.min;
    max = genderRange.max;
    
    if (reference.warningThreshold.male && reference.warningThreshold.female) {
      const genderThreshold = gender === 'male' ? reference.warningThreshold.male : reference.warningThreshold.female;
      highMin = genderThreshold.highMin;
      lowMax = genderThreshold.lowMax;
    }
  } else {
    min = reference.normalRange.min || null;
    max = reference.normalRange.max || null;
    highMin = reference.warningThreshold.highMin;
    lowMax = reference.warningThreshold.lowMax;
  }
  
  if (max !== null && highMin !== undefined && value >= highMin && value <= max) {
    return 'approaching-high';
  }
  
  if (min !== null && lowMax !== undefined && value >= min && value <= lowMax) {
    return 'approaching-low';
  }
  
  return null;
};

// 獲取警告訊息
export const getWarningMessage = (key: string, status: 'approaching-high' | 'approaching-low'): string => {
  if (status === 'approaching-high') {
    return `您的${getChineseLabel(key)}接近上限，請留意`;
  } else {
    return `您的${getChineseLabel(key)}接近下限，請留意`;
  }
};

// 分析趨勢（檢測連續三年上升/下降且接近或超過正常範圍）
export const analyzeTrend = (data: PatientData[], key: keyof PatientData): TrendData | null => {
  if (data.length < 3) return null;
  
  // 按年份排序
  const sortedData = [...data].sort((a, b) => a.year - b.year);
  const lastThreeYears = sortedData.slice(-3);
  
  // 提取數值
  const values = lastThreeYears.map(d => d[key]);
  
  // 檢查類型，如果不是數字則返回null
  if (typeof values[0] !== 'number') return null;
  
  // 檢查趨勢
  const isIncreasing = values[0] < values[1] && values[1] < values[2];
  const isDecreasing = values[0] > values[1] && values[1] > values[2];
  
  if (!isIncreasing && !isDecreasing) return null;
  
  // 檢查最新值是否接近或超過正常範圍
  const latestValue = values[2] as number;
  const reference = referenceData[key as string];
  const gender = lastThreeYears[2].gender;
  
  if (!reference) return null;
  
  let min: number | null = null;
  let max: number | null = null;
  let highMin: number | undefined;
  let lowMax: number | undefined;
  
  if (reference.normalRange.male && reference.normalRange.female) {
    const genderRange = gender === 'male' ? reference.normalRange.male : reference.normalRange.female;
    min = genderRange.min;
    max = genderRange.max;
    
    if (reference.warningThreshold.male && reference.warningThreshold.female) {
      const genderThreshold = gender === 'male' ? reference.warningThreshold.male : reference.warningThreshold.female;
      highMin = genderThreshold.highMin;
      lowMax = genderThreshold.lowMax;
    }
  } else {
    min = reference.normalRange.min || null;
    max = reference.normalRange.max || null;
    highMin = reference.warningThreshold.highMin;
    lowMax = reference.warningThreshold.lowMax;
  }
  
  let isBad = false;
  let message = '';
  
  if (isIncreasing && max !== null) {
    const approaching = highMin !== undefined && latestValue >= highMin;
    const exceeding = latestValue > max;
    
    if (exceeding) {
      isBad = true;
      message = `${getChineseLabel(key as string)}連續三年上升，且已超過正常範圍上限`;
    } else if (approaching) {
      isBad = true;
      message = `${getChineseLabel(key as string)}連續三年上升，且接近正常範圍上限`;
    }
  }
  
  if (isDecreasing && min !== null) {
    const approaching = lowMax !== undefined && latestValue <= lowMax;
    const exceeding = latestValue < min;
    
    if (exceeding) {
      isBad = true;
      message = `${getChineseLabel(key as string)}連續三年下降，且已低於正常範圍下限`;
    } else if (approaching) {
      isBad = true;
      message = `${getChineseLabel(key as string)}連續三年下降，且接近正常範圍下限`;
    }
  }
  
  if (!message) return null;
  
  return {
    name: key as string,
    isBad,
    message
  };
};

// 獲取預警數據
export const getWarningData = (patientData: PatientData): WarningData[] => {
  const warningData: WarningData[] = [];
  
  // 檢查數值型數據
  const numericKeys = [
    'bmi', 'systolicBP', 'diastolicBP', 'wbc', 'rbc', 'hb', 'plt', 
    'gpt', 'got', 'fbs', 'totalCholesterol', 'triglyceride'
  ] as const;
  
  for (const key of numericKeys) {
    const value = patientData[key];
    const status = isApproachingAbnormal(key, value, patientData.gender);
    
    if (status) {
      const reference = referenceData[key];
      let normalRange = '';
      
      if (reference.normalRange.male && reference.normalRange.female) {
        const genderRange = patientData.gender === 'male' ? reference.normalRange.male : reference.normalRange.female;
        normalRange = `${genderRange.min} - ${genderRange.max} ${reference.normalRange.unit}`;
      } else {
        normalRange = `${reference.normalRange.min || ''} - ${reference.normalRange.max || ''} ${reference.normalRange.unit}`;
      }
      
      warningData.push({
        name: key,
        value,
        normalRange,
        status,
        description: getWarningMessage(key, status)
      });
    }
  }
  
  return warningData;
};

// 獲取中文標籤
export const getChineseLabel = (key: string): string => {
  const labelMap: Record<string, string> = {
    patientId: '病歷號',
    gender: '性別',
    year: '年份',
    height: '身高',
    weight: '體重',
    bmi: 'BMI',
    systolicBP: '收縮壓',
    diastolicBP: '舒張壓',
    wbc: '白血球',
    rbc: '紅血球',
    hb: '血紅素',
    plt: '血小板',
    urineProtein: '尿蛋白',
    urineBlood: '尿潛血',
    urineSugar: '尿糖',
    gpt: 'GPT',
    got: 'GOT',
    fbs: '空腹血糖',
    totalCholesterol: '總膽固醇',
    triglyceride: '三酸甘油脂'
  };
  
  return labelMap[key] || key;
};

// 獲取正常值範圍
export const getNormalRange = (key: string, gender?: string): string | null => {
  const reference = referenceData[key];
  if (!reference) return null;
  
  const { unit } = reference.normalRange;
  
  if (reference.normalRange.male && reference.normalRange.female && gender) {
    const genderRange = gender === 'male' ? reference.normalRange.male : reference.normalRange.female;
    return `${genderRange.min} - ${genderRange.max} ${unit}`;
  }
  
  const { min, max } = reference.normalRange;
  if (min === null && max === null) return null;
  
  return `${min || ''} - ${max || ''} ${unit}`;
};