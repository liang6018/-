import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import Layout from './components/Layout';
import LoginForm from './components/LoginForm';
import AnnualReport from './components/AnnualReport';
import TrendAnalysis from './components/TrendAnalysis';
import WarningPage from './components/WarningPage';
import { useAuth } from './context/AuthContext';

const ProtectedRoutes = () => {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<AnnualReport />} />
        <Route path="/trends" element={<TrendAnalysis />} />
        <Route path="/warnings" element={<WarningPage />} />
      </Routes>
    </Layout>
  );
};

const AppRoutes = () => {
  const { isAuthenticated } = useAuth();
  
  if (!isAuthenticated) {
    return <LoginForm />;
  }
  
  return <ProtectedRoutes />;
};

function App() {
  return (
    <Router>
      <AuthProvider>
        <DataProvider>
          <AppRoutes />
        </DataProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;