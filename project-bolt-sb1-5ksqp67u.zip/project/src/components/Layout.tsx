import React, { ReactNode } from 'react';
import { useAuth } from '../context/AuthContext';
import Navigation from './Navigation';
import { Activity, LogOut } from 'lucide-react';

interface LayoutProps {
  children: ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { isAuthenticated, patientId, logout } = useAuth();

  if (!isAuthenticated) {
    return <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">{children}</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <Activity className="h-8 w-8 text-blue-600 mr-2" />
            <h1 className="text-2xl font-bold text-gray-900">醫療報告查詢系統</h1>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">
              病歷號：<span className="font-semibold">{patientId}</span>
            </span>
            <button
              onClick={logout}
              className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm leading-4 font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <LogOut className="h-4 w-4 mr-1" />
              登出
            </button>
          </div>
        </div>
      </header>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Navigation />
        <main className="mt-6 bg-white shadow sm:rounded-lg">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;