import React from 'react';
import { useData } from '../context/DataContext';
import { getChineseLabel } from '../utils/dataUtils';
import { AlertTriangle } from 'lucide-react';

const WarningPage = () => {
  const { warningData } = useData();

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold text-gray-900 mb-6">健康預警</h2>

      {warningData.length > 0 ? (
        <div className="grid gap-6">
          {warningData.map((warning, index) => (
            <div
              key={index}
              className="bg-white rounded-lg shadow overflow-hidden border-l-4 border-red-500"
            >
              <div className="p-5">
                <div className="flex items-center">
                  <AlertTriangle className="h-5 w-5 text-red-500 mr-2" />
                  <h3 className="text-lg font-medium text-gray-900">
                    {getChineseLabel(warning.name)}
                  </h3>
                </div>
                <div className="mt-4">
                  <div className="text-sm text-gray-600">
                    <span className="font-medium">目前數值：</span>
                    <span className="text-red-600 font-semibold">{warning.value}</span>
                  </div>
                  <div className="text-sm text-gray-600 mt-1">
                    <span className="font-medium">正常範圍：</span>
                    {warning.normalRange}
                  </div>
                  <div className="mt-3 text-sm text-red-600">
                    {warning.description}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <AlertTriangle className="h-12 w-12 text-green-500 mx-auto mb-4" />
          <p className="text-lg text-gray-600">目前沒有需要特別注意的健康指標</p>
        </div>
      )}
    </div>
  );
};

export default WarningPage;