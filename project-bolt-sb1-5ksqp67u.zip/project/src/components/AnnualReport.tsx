import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { referenceData } from '../data/referenceData';
import { getChineseLabel, isAbnormal, getNormalRange } from '../utils/dataUtils';
import { AlertCircle } from 'lucide-react';

const AnnualReport = () => {
  const { currentYearData, selectedYear, setSelectedYear } = useData();
  const [selectedItem, setSelectedItem] = useState<string | null>(null);

  const years = [2024, 2023, 2022, 2021, 2020];

  const handleYearChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedYear(parseInt(e.target.value));
  };

  const getAbnormalInfo = (key: string) => {
    const reference = referenceData[key];
    if (!reference) return null;

    const value = currentYearData?.[key as keyof typeof currentYearData];
    if (typeof value !== 'number') return null;

    const isAbnormalValue = isAbnormal(key, value, currentYearData?.gender);
    if (!isAbnormalValue) return null;

    let min: number | null = null;
    let max: number | null = null;

    if (reference.normalRange.male && reference.normalRange.female && currentYearData?.gender) {
      const genderRange = currentYearData.gender === 'male' ? reference.normalRange.male : reference.normalRange.female;
      min = genderRange.min;
      max = genderRange.max;
    } else {
      min = reference.normalRange.min;
      max = reference.normalRange.max;
    }

    const isHigh = max !== null && value > max;
    const isLow = min !== null && value < min;

    if (!isHigh && !isLow) return null;

    const abnormalType = isHigh ? 'high' : 'low';
    return reference.abnormal[abnormalType];
  };

  const renderValue = (key: string, value: any) => {
    if (typeof value !== 'number') return value;

    const reference = referenceData[key];
    if (!reference) return value;

    const isAbnormalValue = isAbnormal(key, value, currentYearData?.gender);
    const normalRange = getNormalRange(key, currentYearData?.gender);
    const unit = reference.normalRange.unit;

    return (
      <div className="flex items-center justify-between">
        <button
          className={`text-left ${isAbnormalValue ? 'text-red-600 font-semibold' : ''}`}
          onClick={() => setSelectedItem(isAbnormalValue ? key : null)}
        >
          {value} {unit}
          {isAbnormalValue && <AlertCircle className="inline ml-1 h-4 w-4" />}
        </button>
        {normalRange && (
          <span className="text-xs text-gray-500 ml-2">
            正常值: {normalRange}
          </span>
        )}
      </div>
    );
  };

  const abnormalInfo = selectedItem ? getAbnormalInfo(selectedItem) : null;

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-900">年度健康檢查報告</h2>
        <select
          value={selectedYear}
          onChange={handleYearChange}
          className="block w-32 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        >
          {years.map(year => (
            <option key={year} value={year}>{year} 年</option>
          ))}
        </select>
      </div>

      {currentYearData ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900 mb-4">基本資料</h3>
              <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                {['height', 'weight', 'bmi'].map(key => (
                  <div key={key} className="col-span-2">
                    <dt className="text-sm font-medium text-gray-500">{getChineseLabel(key)}</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {renderValue(key, currentYearData[key as keyof typeof currentYearData])}
                    </dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900 mb-4">血壓</h3>
              <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                {['systolicBP', 'diastolicBP'].map(key => (
                  <div key={key} className="col-span-2">
                    <dt className="text-sm font-medium text-gray-500">{getChineseLabel(key)}</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {renderValue(key, currentYearData[key as keyof typeof currentYearData])}
                    </dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900 mb-4">血液檢查</h3>
              <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                {['wbc', 'rbc', 'hb', 'plt'].map(key => (
                  <div key={key} className="col-span-2">
                    <dt className="text-sm font-medium text-gray-500">{getChineseLabel(key)}</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {renderValue(key, currentYearData[key as keyof typeof currentYearData])}
                    </dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900 mb-4">尿液檢查</h3>
              <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                {['urineProtein', 'urineBlood', 'urineSugar'].map(key => (
                  <div key={key} className="col-span-2">
                    <dt className="text-sm font-medium text-gray-500">{getChineseLabel(key)}</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {currentYearData[key as keyof typeof currentYearData]}
                    </dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900 mb-4">肝功能</h3>
              <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                {['gpt', 'got'].map(key => (
                  <div key={key} className="col-span-2">
                    <dt className="text-sm font-medium text-gray-500">{getChineseLabel(key)}</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {renderValue(key, currentYearData[key as keyof typeof currentYearData])}
                    </dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium leading-6 text-gray-900 mb-4">血糖與血脂</h3>
              <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                {['fbs', 'totalCholesterol', 'triglyceride'].map(key => (
                  <div key={key} className="col-span-2">
                    <dt className="text-sm font-medium text-gray-500">{getChineseLabel(key)}</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {renderValue(key, currentYearData[key as keyof typeof currentYearData])}
                    </dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-gray-500">無此年度資料</p>
        </div>
      )}

      {/* 異常值說明彈出視窗 */}
      {selectedItem && abnormalInfo && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-lg w-full p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              {getChineseLabel(selectedItem)} 異常說明
            </h3>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-gray-700">可能疾病：</h4>
                <ul className="mt-2 list-disc list-inside text-gray-600">
                  {abnormalInfo.possibleDiseases.map((disease, index) => (
                    <li key={index}>{disease}</li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="font-medium text-gray-700">建議解決方法：</h4>
                <ul className="mt-2 list-disc list-inside text-gray-600">
                  {abnormalInfo.solutions.map((solution, index) => (
                    <li key={index}>{solution}</li>
                  ))}
                </ul>
              </div>
            </div>
            <button
              onClick={() => setSelectedItem(null)}
              className="mt-6 w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              關閉
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AnnualReport;