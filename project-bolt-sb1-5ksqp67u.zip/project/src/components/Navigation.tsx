import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ClipboardList, TrendingUp, AlertTriangle } from 'lucide-react';

const Navigation: React.FC = () => {
  const location = useLocation();
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };
  
  const navItems = [
    { 
      path: '/', 
      label: '年度報告查詢', 
      icon: <ClipboardList className="h-5 w-5" /> 
    },
    { 
      path: '/warnings', 
      label: '健康預警', 
      icon: <AlertTriangle className="h-5 w-5" /> 
    },
    { 
      path: '/trends', 
      label: '五年趨勢分析', 
      icon: <TrendingUp className="h-5 w-5" /> 
    }

  ];

  return (
    <nav className="border-b border-gray-200">
      <ul className="flex space-x-8">
        {navItems.map((item) => (
          <li key={item.path}>
            <Link
              to={item.path}
              className={`flex items-center px-1 py-4 text-sm font-medium border-b-2 ${
                isActive(item.path)
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <span className="mr-2">{item.icon}</span>
              {item.label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Navigation;