import React from 'react';
import { useData } from '../context/DataContext';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
  ReferenceArea
} from 'recharts';
import { getChineseLabel } from '../utils/dataUtils';
import { AlertTriangle } from 'lucide-react';
import { referenceData } from '../data/referenceData';

const TrendAnalysis = () => {
  const { patientData, trendData } = useData();

  const metrics = [
    'bmi',
    'systolicBP',
    'diastolicBP',
    'wbc',
    'rbc',
    'hb',
    'plt',
    'gpt',
    'got',
    'fbs',
    'totalCholesterol',
    'triglyceride'
  ];

  const getChartData = (metric: string) => {
    return patientData.map(data => ({
      year: data.year,
      value: data[metric as keyof typeof data]
    }));
  };

  const getReferenceRange = (metric: string, gender?: string) => {
    const reference = referenceData[metric];
    if (!reference) return null;

    if (reference.normalRange.male && reference.normalRange.female && gender) {
      const genderRange = gender === 'male' ? reference.normalRange.male : reference.normalRange.female;
      return {
        min: genderRange.min,
        max: genderRange.max,
        unit: reference.normalRange.unit
      };
    }

    return {
      min: reference.normalRange.min,
      max: reference.normalRange.max,
      unit: reference.normalRange.unit
    };
  };

  const getYAxisDomain = (metric: string) => {
    const fixedDomains: Record<string, [number, number]> = {
      bmi: [15, 30],
      systolicBP: [80, 150],
      diastolicBP: [50, 100],
      wbc: [0, 15],
      rbc: [2, 7],
      hb: [8, 18],
      plt: [100, 450],
      gpt: [0, 50],
      got: [0, 50],
      fbs: [50, 125],
      totalCholesterol: [100, 250],
      triglyceride: [0, 200]
    };
    return fixedDomains[metric] || ['dataMin - 5', 'dataMax + 5'];
  };

  const getAbnormalYears = (metric: string): { year: number; type: 'high' | 'low' }[] => {
    return patientData
      .filter(data => {
        const reference = getReferenceRange(metric, data.gender);
        if (!reference || reference.min === null || reference.max === null) return false;

        const value = data[metric as keyof typeof data];
        return value < reference.min || value > reference.max;
      })
      .map(data => {
        const reference = getReferenceRange(metric, data.gender);
        const value = data[metric as keyof typeof data];
        return {
          year: data.year,
          type: value > reference!.max! ? 'high' : 'low'
        };
      });
  };

  const CustomTooltip = ({ active, payload, label, metric }: any) => {
    if (!active || !payload || !payload.length) return null;

    const value = payload[0].value;
    const yearData = patientData.find(data => data.year === label);
    const reference = getReferenceRange(metric, yearData?.gender);

    return (
      <div className="bg-white p-3 shadow-lg rounded-lg border">
        <p className="font-medium">{label} 年</p>
        <p className="text-sm">
          {getChineseLabel(metric)}: {value} {reference?.unit}
        </p>
        {reference && reference.min !== null && reference.max !== null && (
          <p className="text-xs text-gray-500 mt-1">
            正常範圍: {reference.min} - {reference.max} {reference.unit}
          </p>
        )}
      </div>
    );
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold text-gray-900 mb-6">五年趨勢分析</h2>

      {trendData.length > 0 && (
        <div className="mb-8 bg-orange-50 border-l-4 border-orange-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertTriangle className="h-5 w-5 text-orange-400" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-orange-800">需要注意的趨勢</h3>
              <div className="mt-2 text-sm text-orange-700">
                <ul className="list-disc list-inside">
                  {trendData.map((trend, index) => (
                    <li key={index}>{trend.message}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {metrics.map(metric => {
          const latestData = patientData[patientData.length - 1];
          const reference = getReferenceRange(metric, latestData?.gender);
          const abnormalYears = getAbnormalYears(metric);
          const yAxisDomain = getYAxisDomain(metric);

          return (
            <div key={metric} className="bg-white p-4 rounded-lg shadow">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                {getChineseLabel(metric)} 趨勢
                {reference && reference.min !== null && reference.max !== null && (
                  <span className="text-sm font-normal text-gray-500 ml-2">
                    (正常範圍: {reference.min} - {reference.max} {reference.unit})
                  </span>
                )}
              </h3>

              {abnormalYears.length > 0 && (
                <div className="mb-2 p-2 bg-red-50 border-l-4 border-red-400 text-sm text-red-700 rounded">
                  {(() => {
                    const highYears = abnormalYears.filter(y => y.type === 'high').map(y => y.year);
                    const lowYears = abnormalYears.filter(y => y.type === 'low').map(y => y.year);
                    return (
                      <>
                        {highYears.length > 0 && (
                          <div>⚠️ 異常提醒：{highYears.join('、')} 年數值高於正常範圍</div>
                        )}
                        {lowYears.length > 0 && (
                          <div>⚠️ 異常提醒：{lowYears.join('、')} 年數值低於正常範圍</div>
                        )}
                      </>
                    );
                  })()}
                </div>
              )}

              <div className="h-64 min-w-[360px] overflow-visible">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={getChartData(metric)}
                    margin={{ top: 5, right: 40, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis domain={yAxisDomain} />
                    <Tooltip content={<CustomTooltip metric={metric} />} />
                    <Legend />
                    {reference && reference.min !== null && reference.max !== null && (
                      <>
                        <ReferenceArea
                          y1={reference.max}
                          y2={yAxisDomain[1]}
                          strokeOpacity={0}
                          fill="#fee2e2"
                        />
                        <ReferenceArea
                          y1={yAxisDomain[0]}
                          y2={reference.min}
                          strokeOpacity={0}
                          fill="#dbeafe"
                        />
                        <ReferenceLine
                          y={reference.max}
                          stroke="#ef4444"
                          strokeDasharray="3 3"
                          strokeWidth={2}
                          label={{ value: '上限', position: 'insideTopRight', fill: '#ef4444' }}
                        />
                        <ReferenceLine
                          y={reference.min}
                          stroke="#3b82f6"
                          strokeDasharray="3 3"
                          strokeWidth={2}
                          label={{ value: '下限', position: 'insideBottomRight', fill: '#3b82f6' }}
                        />
                      </>
                    )}
                    <Line
                      type="monotone"
                      dataKey="value"
                      name={getChineseLabel(metric)}
                      stroke="#573e00"
                      strokeWidth={2}
                      activeDot={{ r: 8 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default TrendAnalysis;
